<!DOCTYPE html>
<html lang="id">
<head>
    
    <?php include $_SERVER['DOCUMENT_ROOT'] . '/pixel.php'; ?>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Beliyuk.shop — Landing Page Usaha Pribadi</title>

<style>
body {
    margin: 0;
    font-family: Arial, sans-serif;
    background: #0d0d0d; /* DARK MODE */
    color: #f8f9fa;
}

/* HEADER */
header {
    background: linear-gradient(135deg, #ffd000, #ffea74); /* KUNING */
    padding: 80px 20px;
    text-align: center;
    color: #000;
}

header h1 {
    font-size: 42px;
    margin-bottom: 10px;
    font-weight: 900;
}

header p {
    font-size: 18px;
    opacity: 0.9;
}

.btn-contact {
    display: inline-block;
    margin-top: 25px;
    padding: 12px 28px;
    background: #000;
    color: #ffd000;
    border-radius: 8px;
    text-decoration: none;
    font-size: 18px;
    font-weight: bold;
    transition: all 0.3s ease;
}

.btn-contact:hover {
    background: #222;
}

/* CONTAINER */
.container {
    width: 90%;
    max-width: 900px;
    margin: 40px auto;
}

.section-title {
    text-align: center;
    font-size: 28px;
    margin-bottom: 25px;
    color: #ffd000;
    font-weight: bold;
}

/* DARK CARD STYLE */
.box, .product-card {
    background: #1c1c1c;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0px 4px 10px rgba(255, 255, 255, 0.05);
    color: #fff;
}

/* PRODUCT CATALOG */
.catalog-new {
    display: grid;
    grid-template-columns: 1fr;
    gap: 25px;
}

@media (min-width: 700px) {
    .catalog-new {
        grid-template-columns: repeat(2, 1fr);
    }
}

.product-card img {
    width: 100%;
    border-radius: 12px;
    aspect-ratio: 1/1;
    object-fit: cover;
    margin-bottom: 15px;
}

.product-title {
    font-size: 20px;
    font-weight: bold;
    margin-bottom: 8px;
    color: #ffd000;
}

.product-desc {
    font-size: 14px;
    color: #ccc;
    margin-bottom: 12px;
    line-height: 1.45;
}

/* BUTTON BELI SEKARANG */
/* GANTI TOMBOL BELI DENGAN ANIMASI DIAGONAL */
.buy-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    position: relative;
    overflow: hidden;
    padding: 10px 20px;
    background: #ffd000;
    color: #000;
    border-radius: 8px;
    font-weight: bold;
    font-size: 14px;
    text-decoration: none;
    cursor: pointer;
    /* Tambahkan ini untuk positioning */
    isolation: isolate;
}

/* ANIMASI DIAGONAL DARI KIRI BAWAH KE KANAN ATAS */
.buy-btn::before {
    content: '';
    position: absolute;
    width: 150%; /* Lebar garis cahaya */
    height: 20px; /* Ketebalan garis cahaya */
    background: linear-gradient(
        45deg, /* Sudut 45 derajat untuk diagonal */
        rgba(255, 255, 255, 0) 0%,
        rgba(255, 255, 255, 0.8) 50%,
        rgba(255, 255, 255, 0) 100%
    );
    
    /* Mulai dari kiri bawah */
    bottom: -20px;
    left: -100%;
    
    /* Rotasi untuk efek diagonal */
    transform: rotate(45deg);
    transform-origin: left bottom;
    
    animation: diagonal-sweep 1.5s infinite;
    z-index: -1;
}

@keyframes diagonal-sweep {
    0% {
        left: -100%;
        bottom: -20px;
    }
    100% {
        left: 100%;
        bottom: calc(100% + 20px);
    }
}






/* FEATURES */
.features {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 25px;
}

.box h3 {
    color: #ffd000;
    margin-bottom: 8px;
}

footer {
    text-align: center;
    padding: 25px;
    margin-top: 40px;
    background: #111;
    font-size: 14px;
    color: #ccc;
}

footer a {
    color: #ffd000;
    text-decoration: none;
    margin: 0 10px;
}

footer a:hover {
    text-decoration: underline;
}
</style>
</head>
<body>

<!-- HEADER -->
<header>
    
    <h1>Selamat Datang di Beliyuk.shop</h1>
    <p>Landing Page Usaha Pribadi — Tempat Anda Mendapatkan Produk & Layanan Terbaik</p>
    <a href="https://dst.skuylah.click/wa" class="btn-contact">Hubungi Saya</a>
</header>

<!-- ABOUT -->
<div class="container">
    <h2 class="section-title">Tentang Usaha Saya</h2>
    <p style="text-align:center; max-width:700px; margin:auto; color:#ccc;">
        Beliyuk.shop adalah landing page sederhana untuk menampilkan produk dan layanan usaha pribadi saya.
        Dibuat agar pelanggan dapat melihat penawaran terbaik dengan jelas dan mudah.
    </p>
</div>

<!-- PRODUCT CATALOG -->
<div class="container">
    <h2 class="section-title">Katalog Produk</h2>
    <div class="catalog-new">
        <!-- PRODUK 1 -->
        <div class="product-card">
            <img src="https://imgdst.tomsamcong.com/public/uploads/original/65/6b/35ef31fbe97ddeb5f4f18a04c1b7.webp">
            <div class="product-title">1.999+ E-BOOKS</div>
            <div class="product-desc">
                Koleksi 1.999+ e-book tentang self improvement, mindset, bisnis, dan pengembangan diri. Praktis dan bisa dibaca di semua perangkat.
            </div>
            <a href="./product/1.999%2b%20E-BOOKS/" class="buy-btn">Beli Sekarang</a>
        </div>
        
         <!-- PRODUK 2 -->
        <div class="product-card">
            <img src="https://imgdst.tomsamcong.com/public/uploads/original/91/19/3191eb7f4403af2b128685e26ca0.png">
            <div class="product-title">Atomic Habits E-BOOKS</div>
            <div class="product-desc">
                Buku Atomic Habits karya James Clear, Pelajari cara membangun kebiasaan kecil yang menghasilkan perubahan besar. Praktis, mudah diterapkan, dan membantu meningkatkan produktivitas serta disiplin setiap hari.
            </div>
            <a href="./product/ATOMIC HABITS" class="buy-btn">Beli Sekarang</a>
        </div>
        
    </div>
</div>

<!-- FEATURES -->
<div class="container">
    <h2 class="section-title">Kenapa Memilih Saya?</h2>
    <div class="features">
        <div class="box">
            <h3>✔ Kualitas Terbaik</h3>
            <p>Produk dan layanan dengan kualitas terbaik untuk kepuasan pelanggan.</p>
        </div>
        <div class="box">
            <h3>✔ Harga Terjangkau</h3>
            <p>Harga bersahabat tanpa mengorbankan kualitas.</p>
        </div>
        <div class="box">
            <h3>✔ Respon Cepat</h3>
            <p>Fast Response via WhatsApp — ramah, cepat, dan profesional.</p>
        </div>
    </div>
</div>

<!-- FOOTER -->
<footer>
    © 2025 Beliyuk.shop — Usaha Pribadi  
    <br><br>
    <a href="/terms-and-conditions">Terms and Conditions</a> | 
    <a href="/refund-policy">Refund Policy</a> |
    <a href="/support">Support</a>
</footer>

</body>
</html>
