<?php
// index.php - Landing Page Promo Buku Paketan
?>
<!DOCTYPE html>
<html lang="id">

<head>

<?php include $_SERVER['DOCUMENT_ROOT'] . '/pixel.php'; ?>

<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Promo Buku Paketan - TomCamSong Shop</title>

<style>
    body {
        margin: 0;
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background: linear-gradient(135deg, #0d0d0d 0%, #1a1a1a 100%);
        color: #f6f6f6;
        line-height: 1.6;
    }
    
    header {
        background: linear-gradient(135deg, #facc15, #eab308, #d97706);
        padding: 60px 20px;
        text-align: center;
        color: #000;
        position: relative;
        overflow: hidden;
    }
    
    header h1 {
        font-size: 42px;
        margin-bottom: 15px;
        font-weight: 900;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
    }
    
    header p {
        font-size: 18px;
        opacity: 0.95;
        font-weight: 600;
        max-width: 800px;
        margin: 0 auto;
    }

    .container {
        width: 90%;
        max-width: 1200px;
        margin: 30px auto;
        padding: 0 15px;
    }

    .section-title {
        text-align: center;
        font-size: 32px;
        margin-bottom: 30px;
        color: #facc15;
        font-weight: 800;
        position: relative;
        padding-bottom: 12px;
    }
    
    .section-title::after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 50%;
        transform: translateX(-50%);
        width: 80px;
        height: 4px;
        background: linear-gradient(90deg, #facc15, #eab308);
        border-radius: 2px;
    }

   /* === PRODUCT CARD - WARNA WARNI TANPA GLOW & RINGAN === */

    .product-card {
        background: #1a1a1a;
        border-radius: 12px;
        padding: 16px 14px;
        text-align: center;
        margin: 0 auto 18px;
        max-width: 420px;
        position: relative;
        z-index: 1;

        /* TEKNIK BORDER PELANGI TAJAM */
        border: 3px solid transparent; 
        background-image: 
            linear-gradient(#1a1a1a, #1a1a1a),
            linear-gradient(90deg, #ff0000, #ff7f00, #ffff00, #00ff00, #0000ff, #4b0082, #9400d3); 
        
        background-origin: border-box;
        background-clip: padding-box, border-box;
        box-shadow: 0 10px 20px rgba(0,0,0,0.5);
    }

    /* Title */
    .product-title {
        font-size: 28px;
        font-weight: 800;
        color: #facc15;
        margin-bottom: 10px;
    }

    /* Badge */
    .product-badge {
        display: inline-block;
        background: #ff3c3c;
        padding: 4px 10px;
        border-radius: 6px;
        font-size: 11px;
        color: #fff;
        margin-bottom: 8px;
        font-weight: 600;
    }

    /* Gambar Produk */
    .product-image {
        width: 100%;
        max-width: 300px;
        border-radius: 15px;
        margin: 20px auto 25px;
        display: block;
        border: 2px solid #333;
        box-shadow: 0 5px 15px rgba(0,0,0,0.5);
        transition: transform 0.3s ease;
    }
    
    .product-image:hover {
        transform: scale(1.02);
    }

    /* Harga compact */
    .product-price {
        font-size: 26px;
        font-weight: 700;
        color: #fff;
        margin: 15px 0;
        background: linear-gradient(90deg, #facc15, #eab308);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        background-clip: text;
        display: inline-block;
        padding: 8px 16px;
        border-radius: 10px;
        background-color: rgba(250, 204, 21, 0.05); 
        border: 1px solid rgba(250, 204, 21, 0.2);
    }

    /* === FORM EMAIL STYLES === */
    .email-form-wrap {
        background: rgba(26, 26, 26, 0.9);
        padding: 20px;
        border-radius: 12px;
        margin: 20px auto;
        border: 1px solid rgba(250, 204, 21, 0.3);
        max-width: 500px;
    }

    .email-label {
        display: block;
        color: #facc15;
        font-weight: 600;
        margin-bottom: 10px;
        font-size: 16px;
        text-align: center;
    }

    .email-input {
        width: 100%;
        padding: 14px 18px;
        border-radius: 10px;
        border: 2px solid #333;
        background: #0d0d0d;
        color: #fff;
        font-size: 16px;
        transition: all 0.3s ease;
        box-sizing: border-box;
    }

    .email-input:focus {
        outline: none;
        border-color: #facc15;
    }

    .email-input.valid {
        border-color: #22c55e;
        background: rgba(34, 197, 94, 0.05);
    }

    .email-input.invalid {
        border-color: #ef4444;
        background: rgba(239, 68, 68, 0.05);
    }

    .email-note {
        font-size: 13px;
        color: #aaa;
        margin-top: 8px;
        text-align: center;
    }

    /* QUANTITY SECTION */
    .qty-wrap {
        text-align: center;
        margin: 30px 0;
        padding: 15px;
        background: rgba(0, 0, 0, 0.3);
        border-radius: 15px;
        border: 1px solid #444;
    }
    
    .qty-label {
        display: block;
        font-size: 16px;
        margin-bottom: 10px;
        color: #facc15;
        font-weight: 700;
    }
    
    .qty-input-wrapper {
        display: inline-flex;
        align-items: center;
        gap: 10px;
        justify-content: center;
    }
    
    .qty-btn {
        background: #333;
        color: #fff;
        border: 1px solid #555;
        width: 40px;
        height: 40px;
        border-radius: 8px;
        font-size: 20px;
        font-weight: bold;
        cursor: pointer;
        display: flex;
        align-items: center;
        justify-content: center;
        transition: background 0.2s;
    }
    
    .qty-btn:hover {
        background: #444;
        border-color: #facc15;
    }
    
    .qty-input {
        padding: 10px;
        width: 80px;
        font-size: 18px;
        border-radius: 8px;
        border: 1px solid #555;
        text-align: center;
        background: #000;
        color: #fff;
        font-weight: bold;
    }

    /* TOTAL INFO */
    .total-info-simple {
        text-align: center;
        margin: 20px 0 30px;
        padding: 15px;
        background: #222;
        border-radius: 10px;
        border: 1px solid #333;
    }
    
    .total-label-simple {
        color: #ccc;
        font-size: 14px;
        margin-bottom: 5px;
    }
    
    .total-amount-simple {
        color: #facc15;
        font-size: 22px;
        font-weight: 800;
    }

    /* === BUTTON WRAPPER UNTUK OVERLAY NOTIFIKASI === */
    .btn-container {
        position: relative;
        width: 100%;
        max-width: 350px;
        margin: 15px auto;
        display: block;
    }

    /* === TOMBOL BAYAR DENGAN LIGHT SWEEP ANIMATION === */
    .buy-btn2 {
        position: relative;
        padding: 16px 30px;
        background: #facc15; 
        color: #000;
        border-radius: 10px;
        text-decoration: none;
        font-weight: 800;
        font-size: 18px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
        border: none;
        width: 100%;
        transition: background 0.3s ease;
        box-shadow: 0 4px 0 #d97706;
        
        /* PENTING: Agar cahaya tidak keluar dari tombol */
        overflow: hidden; 
    }
    
    .buy-btn2:hover {
        background: #eab308;
        transform: translateY(-2px);
    }

    .buy-btn2:active {
        transform: translateY(2px);
        box-shadow: none;
    }
    
    .buy-btn2:disabled {
        background: #555;
        color: #888;
        box-shadow: none;
        cursor: default;
        transform: none;
    }

    /* --- ANIMASI CAHAYA (LIGHT SWEEP) --- */
    .buy-btn2::after {
        content: '';
        position: absolute;
        top: 0;
        left: -150%; /* Start position */
        width: 100%;
        height: 100%;
        
        /* Gradasi putih untuk efek kilatan */
        background: linear-gradient(
            to right,
            rgba(255, 255, 255, 0) 0%,
            rgba(255, 255, 255, 0.6) 50%,
            rgba(255, 255, 255, 0) 100%
        );
        
        /* Miringkan diagonal (kiri bawah ke kanan atas) */
        transform: skewX(-25deg); 
        
        /* Animasi berulang selamanya, bahkan saat disabled */
        animation: lightSweep 3s infinite;
        pointer-events: none; /* Agar tidak menghalangi klik */
        z-index: 5;
    }

    @keyframes lightSweep {
        0% { left: -150%; }
        20% { left: 150%; } /* Gerak cepat lewat tombol */
        100% { left: 150%; } /* Jeda diam sebelum loop ulang */
    }

    /* Pastikan text tombol ada di atas layer cahaya */
    .btn-text {
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 10px;
        position: relative;
        z-index: 10; 
    }
    
    .btn-text .loading-spinner {
        display: inline-block;
        width: 16px;
        height: 16px;
        border: 2px solid rgba(0,0,0,0.3);
        border-top-color: #000;
        border-radius: 50%;
        animation: spin 1s linear infinite;
    }
    
    @keyframes spin {
        to { transform: rotate(360deg); }
    }

    /* === OVERLAY PENUTUP (RAHASIA KLIK TOMBOL DISABLED) === */
    .btn-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 20; /* Lebih tinggi dari tombol */
        cursor: not-allowed;
        display: block; /* Muncul default saat disabled */
    }

    /* Email error message */
    .email-error {
        color: #ef4444;
        font-size: 14px;
        margin-top: 8px;
        text-align: center;
        display: none;
    }

    /* BENEFITS SECTION */
    .benefits-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 25px;
        margin: 40px 0;
    }
    
    .benefit-card {
        background: #1a1a1a;
        padding: 30px 25px;
        border-radius: 16px;
        text-align: center;
        border: 1px solid #333;
        transition: transform 0.3s ease;
        display: flex;
        flex-direction: column;
        height: 100%;
        box-sizing: border-box;
    }
    
    .benefit-card:hover {
        border-color: #facc15;
    }
    
    .benefit-icon {
        font-size: 42px;
        margin-bottom: 15px;
        color: #facc15;
    }
    
    .benefit-card h3 {
        font-size: 22px;
        color: #facc15;
        margin-bottom: 12px;
        font-weight: 700;
    }
    
    .benefit-card p {
        color: #ccc;
        margin-bottom: 15px;
        font-size: 15px;
        line-height: 1.5;
        flex-grow: 0;
    }
    
    .benefit-list {
        text-align: left;
        margin-top: 12px;
        padding: 0;
        list-style: none;
        flex-grow: 1;
    }
    
    .benefit-list li {
        color: #ddd;
        margin-bottom: 8px;
        padding-left: 25px;
        position: relative;
        font-size: 14px;
        line-height: 1.4;
    }
    
    .benefit-list li::before {
        content: '✓';
        position: absolute;
        left: 0;
        color: #facc15;
        font-weight: bold;
        font-size: 16px;
    }

    /* KARTU HEMAT SPECIAL */
    .benefit-card-special {
        background: #1f1f1f;
        border: 1px solid #facc15;
        position: relative;
    }
    
    .price-comparison {
        text-align: center;
        margin: 20px 0;
        padding: 15px;
        background: rgba(0, 0, 0, 0.3);
        border-radius: 10px;
        border: 1px dashed #555;
    }
    
    .old-price {
        font-size: 24px;
        color: #ff4d4d;
        text-decoration: line-through;
        font-weight: bold;
        margin-bottom: 5px;
    }
    
    .today-label {
        font-size: 16px;
        color: #facc15;
        margin: 5px 0;
    }
    
    .new-price {
        font-size: 32px;
        color: #00ff00;
        font-weight: 900;
        margin: 10px 0;
    }
    
    .discount-badge {
        display: inline-block;
        background: #ff0000;
        color: white;
        padding: 6px 15px;
        border-radius: 20px;
        font-weight: bold;
        font-size: 13px;
        margin-top: 10px;
    }
    
    .savings-info {
        margin-top: 15px;
        padding: 10px;
        background: rgba(0, 255, 0, 0.05);
        border-radius: 8px;
        border-left: 3px solid #00ff00;
    }
    
    .savings-info p {
        color: #ddd;
        margin: 5px 0;
        font-size: 14px;
    }
    
    .savings-info strong {
        color: #00ff00;
    }

    /* RESPONSIVE */
    @media (max-width: 768px) {
        header { padding: 40px 15px; }
        header h1 { font-size: 28px; }
        .section-title { font-size: 26px; }
        .product-title { font-size: 24px; }
        .benefits-grid { grid-template-columns: 1fr; }
        .product-card { padding: 20px 15px; }
        .email-form-wrap { padding: 15px; }
    }
    
    @media (max-width: 480px) {
        header h1 { font-size: 24px; }
        .old-price { font-size: 20px; }
        .new-price { font-size: 28px; }
    }

    footer {
        text-align: center;
        padding: 30px 20px;
        margin-top: 50px;
        background: #111;
        border-top: 1px solid #333;
    }
    
    .footer-text {
        color: #777;
        font-size: 14px;
    }
    
    /* DESKRIPSI PRODUK */
    .product-description {
        max-width: 800px;
        margin: 40px auto 30px;
        padding: 25px;
        background: #1a1a1a;
        border-radius: 15px;
        border: 1px solid #333;
    }

    .desc-title {
        color: #facc15;
        font-size: 24px;
        font-weight: 700;
        margin-bottom: 20px;
        text-align: center;
        border-bottom: 2px solid #333;
        padding-bottom: 15px;
    }

    .desc-list {
        list-style: none;
        padding-left: 0;
        margin: 0 0 15px 0;
        max-height: 300px;
        overflow-y: auto;
        padding: 15px;
        background: #222;
        border-radius: 8px;
        border: 1px solid #333;
    }

    .desc-list li {
        padding: 8px 0 8px 25px;
        position: relative;
        border-bottom: 1px dashed #444;
        font-size: 14px;
        color: #ccc;
    }

    .desc-list li::before {
        content: '📖';
        position: absolute;
        left: 0;
        font-size: 12px;
    }

    .desc-list li:last-child {
        border-bottom: none;
    }

    /* TOMBOL READ MORE */
    .read-more-btn {
        display: block !important;
        margin: 25px auto 15px !important;
        padding: 10px 25px !important;
        background: transparent !important;
        border: 1px solid #facc15 !important;
        color: #facc15 !important;
        border-radius: 6px !important;
        font-weight: 600 !important;
        cursor: pointer !important;
        text-align: center !important;
        max-width: 200px !important;
        font-size: 14px !important;
    }
    
    .read-more-btn:hover {
        background: rgba(250, 204, 21, 0.1) !important;
    }
    
    .additional-content {
        margin-top: 20px !important;
        border-top: 1px dashed #444 !important;
        padding-top: 20px !important;
    }
    
    .product-description h4 {
        color: #facc15 !important;
        font-size: 18px !important;
        font-weight: 600 !important;
        margin: 25px 0 15px 0 !important;
        padding-bottom: 8px !important;
        border-bottom: 1px solid #444 !important;
    }
    
    .desc-note {
        background: #222 !important;
        padding: 15px !important;
        border-radius: 8px !important;
        margin-top: 25px !important;
        border-left: 4px solid #facc15 !important;
        font-size: 14px !important;
        color: #aaa !important;
    }
</style>

<script>
// KONFIGURASI
const PRICE = 99999;
const MAX_TOTAL = 10000000;

document.addEventListener('DOMContentLoaded', function () {
    console.log('DOM Content Loaded - Initializing Quantity Controls');
    
    // Elemen yang diperlukan
    const qtyInput = document.getElementById("qty");
    const qtyMinus = document.getElementById("qtyMinus");
    const qtyPlus = document.getElementById("qtyPlus");
    const totalAmount = document.getElementById("totalAmount");
    const buyButton = document.querySelector('.buy-btn2');
    const form = document.getElementById('paymentForm');
    const emailInput = document.getElementById('customerEmail');
    const emailError = document.getElementById('emailError');
    const btnOverlay = document.getElementById('btnOverlay'); // Overlay Penutup
    
    // Fungsi validasi email
    function isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }
    
    // Fungsi update status tombol bayar & Overlay
    function updateBuyButtonState() {
        const email = emailInput.value.trim();
        const isValid = isValidEmail(email);
        
        if (isValid) {
            // Jika valid: Tombol aktif, Overlay sembunyi
            buyButton.disabled = false;
            btnOverlay.style.display = 'none'; 
            
            emailInput.classList.remove('invalid');
            emailInput.classList.add('valid');
            emailError.style.display = 'none';
        } else {
            // Jika tidak valid: Tombol disabled, Overlay muncul
            buyButton.disabled = true;
            btnOverlay.style.display = 'block';
            
            emailInput.classList.remove('valid');
            // Kita tidak langsung kasih error merah sampai user mengetik atau blur
            if (email !== '') {
                emailInput.classList.add('invalid');
                emailError.style.display = 'block';
            }
        }
    }

    // LOGIKA OVERLAY: Saat diklik munculkan notifikasi
    if (btnOverlay) {
        btnOverlay.addEventListener('click', function() {
            // 1. Scroll ke Input Email
            emailInput.scrollIntoView({ behavior: 'smooth', block: 'center' });
            
            // 2. Fokus ke Input
            emailInput.focus();
            
            // 3. Animasi Getar (Shake)
            emailInput.style.animation = "none";
            // Trigger reflow
            void emailInput.offsetWidth;
            emailInput.style.animation = "shake 0.5s";

            // 4. Tampilkan Alert (Pesan Sederhana)
            if (typeof Swal !== 'undefined') {
                Swal.fire({
                    icon: 'info',
                    title: 'Lengkapi Data Anda',
                    text: 'Mohon isi alamat email yang valid untuk melanjutkan pembayaran.',
                    confirmButtonColor: '#facc15',
                    confirmButtonText: 'Siap'
                });
            } else {
                // Gunakan alert browser jika SweetAlert tidak ada
                // alert("⚠ Lengkapi Data Anda!\n\nMohon isi alamat email yang valid untuk melanjutkan.");
                
                // ATAU cukup biarkan fokus ke input tanpa alert agar lebih elegan
            }
        });
    }
    
    // Event listener untuk input email
    emailInput.addEventListener('input', updateBuyButtonState);
    emailInput.addEventListener('blur', updateBuyButtonState);
    
    // Pastikan input number benar-benar bisa diedit
    qtyInput.removeAttribute('readonly');
    qtyInput.removeAttribute('disabled');
    
    // Fungsi untuk menghitung total
    function calculateTotal() {
        let qty = parseInt(qtyInput.value);
        if (isNaN(qty) || qty < 1) { qty = 1; qtyInput.value = 1; }
        return qty * PRICE;
    }
    
    // Fungsi update total display
    function updateTotalDisplay() {
        const total = calculateTotal();
        totalAmount.textContent = 'Rp ' + total.toLocaleString('id-ID');
    }
    
    // Event tombol qty
    qtyMinus.addEventListener('click', function(e) {
        e.preventDefault();
        let currentValue = parseInt(qtyInput.value);
        if (currentValue > 1) { qtyInput.value = currentValue - 1; updateTotalDisplay(); }
    });
    
    qtyPlus.addEventListener('click', function(e) {
        e.preventDefault();
        let currentValue = parseInt(qtyInput.value);
        const maxQty = Math.floor(MAX_TOTAL / PRICE);
        if (currentValue < maxQty) { qtyInput.value = currentValue + 1; updateTotalDisplay(); } 
        else { alert(`Maksimal ${maxQty} item (Total Rp 10.000.000)`); }
    });
    
    qtyInput.addEventListener('input', function() { updateTotalDisplay(); });
    
    // FUNGSI TRACKING PIXEL
    if (buyButton) {
        buyButton.addEventListener('click', function(e) {
             // Tracking FB Pixel (hanya jalan jika button enabled / data valid)
             const quantity = parseInt(qtyInput.value);
             const totalValue = PRICE * quantity;
             
             if (typeof fbq !== 'undefined') {
                fbq('track', 'InitiateCheckout', {
                    value: totalValue,
                    currency: 'IDR',
                    content_type: 'product',
                    contents: [{ id: 'ebook-package-1999', quantity: quantity, item_price: PRICE }],
                    num_items: quantity
                });
            }
        });
    }

    // Fungsi Submit Form
    if (form) {
        form.addEventListener('submit', function(e) {
            const email = emailInput.value.trim();
            if (!isValidEmail(email)) {
                e.preventDefault();
                emailInput.focus();
                return false;
            }
            if (calculateTotal() > MAX_TOTAL) {
                e.preventDefault();
                alert('Total melebihi batas maksimal');
                return false;
            }
            
            const button = document.querySelector('.buy-btn2');
            if (button) {
                const originalText = button.querySelector('.btn-text').innerHTML;
                button.querySelector('.btn-text').innerHTML = '<span class="loading-spinner"></span> MEMPROSES...';
                button.disabled = true;
                
                // PENTING: Sembunyikan overlay saat loading agar tidak bisa diklik lagi
                if(btnOverlay) btnOverlay.style.display = 'none'; 
            }
            
            setTimeout(() => { form.submit(); }, 1000);
        });
    }
    
    // Inisialisasi
    updateTotalDisplay();
    updateBuyButtonState(); // Set state awal
});

// CSS Shake Animation & Input Fix
const styleAdd = document.createElement('style');
styleAdd.textContent = `
    @keyframes shake {
        0% { transform: translateX(0); }
        25% { transform: translateX(-5px); border-color: #ef4444; }
        50% { transform: translateX(5px); }
        75% { transform: translateX(-5px); }
        100% { transform: translateX(0); }
    }
    /* Pastikan input number bisa diedit */
    input#qty { -webkit-user-select: text !important; user-select: text !important; cursor: text !important; pointer-events: auto !important; -webkit-appearance: none !important; -moz-appearance: textfield !important; appearance: none !important; }
    input#qty::-webkit-inner-spin-button, input#qty::-webkit-outer-spin-button { -webkit-appearance: none !important; margin: 0 !important; }
`;
document.head.appendChild(styleAdd);

function toggleDescription() {
    const additionalContent = document.querySelector('.additional-content');
    const readMoreBtn = document.querySelector('.read-more-btn');
    if (additionalContent.style.display === 'none' || additionalContent.style.display === '') {
        additionalContent.style.display = 'block';
        readMoreBtn.innerHTML = 'TUTUP DESKRIPSI ↑';
        setTimeout(() => { additionalContent.scrollIntoView({ behavior: 'smooth', block: 'start' }); }, 100);
    } else {
        additionalContent.style.display = 'none';
        readMoreBtn.innerHTML = 'BACA SELENGKAPNYA ↓';
        setTimeout(() => { readMoreBtn.scrollIntoView({ behavior: 'smooth', block: 'center' }); }, 100);
    }
}
</script>

</head>
<body>

<header>
    <h1>BARU! PROMO BUKU PAKETAN TERLENGKAP!</h1>
    <p>Dapatkan akses ke 1.999+ buku digital premium dengan harga spesial!</p>
</header>

<div class="container">
    <div class="product-card">
        <div class="product-title">Paket Super Lengkap 1.999+ E-Books Premium</div>
        <img src="https://imgdst.tomsamcong.com/public/uploads/original/91/19/3191eb7f4403af2b128685e26ca0.png" 
             alt="Paket Buku Lengkap" class="product-image">

        <form action="create-payment.php" method="POST" id="paymentForm">
            <div class="email-form-wrap">
                <label class="email-label" for="customerEmail">
                    📧 MASUKKAN EMAIL ANDA
                </label>
                <input type="email" 
                       id="customerEmail" 
                       name="customerEmail" 
                       class="email-input" 
                       placeholder="contoh: nama@email.com" 
                       required
                       autocomplete="email">
                <div class="email-error" id="emailError">
                    Format email tidak valid. Contoh: nama@email.com
                </div>
                <div class="email-note">
                    Produk akan dikirim ke email ini setelah pembayaran berhasil
                </div>
            </div>

            <div class="qty-wrap">
                <label class="qty-label">PILIH JUMLAH PAKET:</label>

                <div class="qty-input-wrapper">
                    <button type="button" class="qty-btn" id="qtyMinus">-</button>

                    <input type="number" id="qty" name="qty" class="qty-input"
                           value="1" min="1" max="100">

                    <button type="button" class="qty-btn" id="qtyPlus">+</button>
                </div>
            </div>

            <div class="product-price">
                <div class="total-label-simple">TOTAL YANG HARUS DIBAYAR:</div>
                <div class="total-amount-simple" id="totalAmount">Rp 49.999</div>
            </div>

            <div class="btn-container">
                <button type="submit" class="buy-btn2" disabled>
                    <span class="btn-text">BAYAR SEKARANG</span>
                </button>
                
                <div id="btnOverlay" class="btn-overlay" title="Lengkapi data Anda terlebih dahulu"></div>
            </div>
            
        </form>
    </div>

    <div class="product-description">
        <h3 class="desc-title">Deskripsi Produk</h3>
        
        <button class="read-more-btn" onclick="toggleDescription()">
            BACA SELENGKAPNYA ↓
        </button>
        
        <h4>E-Book ATOMIC HABITS (PDF)</h4> 
        
        <p> Dapatkan e-book <b>Atomic Habits (PDF)</b> hanya dengan <b>Rp49.999</b>. Harga buku fisik bisa mencapai <b>Rp399.000+</b>, lebih mahal dan tidak praktis. Versi e-book jauh lebih <b>ringan, fleksibel,</b> bisa dibaca di mana saja lewat HP atau laptop—tanpa ribet membawa buku tebal. Pilihan hemat untuk Anda yang ingin membangun kebiasaan baik dengan cara lebih efisien. </p>
        
        <div class="additional-content" style="display: none;">
            <h4>SELF IMPROVEMENT</h4>
            <ul class="desc-list">
                <li>AtomicHabits.pdf</li>
            </ul>

            <div class="desc-note">
                <p><strong>Proses Pengerjaan</strong><br>
                </p>
                                <li>1. Member berhasil bayar</li>
                               <li>2. Pihak Penjual Otomatis Kirim Produk lewat Email</li>
                               <li>3. Pihak Penerima Menerima Produk lewat Email</li>

            </div>
        </div>
    </div>

    <h2 class="section-title">APA YANG AKAN ANDA DAPATKAN?</h2>

    <div class="benefits-grid">
        
        <div class="benefit-card benefit-card-special">
            <div class="benefit-icon">💎</div>
            <h3>TOTAL HEMAT</h3>
            <p>Jika beli satuan, totalnya mencapai:</p>
            
            <div class="price-comparison">
                <div class="old-price">
                    Rp 399.999
                </div>
                
                <div class="today-label">
                    HARI INI HANYA:
                </div>
                
                <div class="new-price">
                    Rp 49.999
                </div>
                
                <div class="discount-badge">
                    HEMAT LEBIH DARI 87%!
                </div>
            </div>
            
            <div class="savings-info">
                <p>Anda hemat: <strong>Rp 350.000</strong></p>
                <p>Hanya <strong>Rp 49.999 per buku!</strong></p>
            </div>
        </div>
        
        <div class="benefit-card">
            <div class="benefit-icon">📚</div>
            <h3>KOLEKSI LENGKAP</h3>
            <p>Akses ke 1.999+ buku digital premium dari berbagai kategori:</p>
            <ul class="benefit-list">
                <li>Self Improvement & Motivasi</li>
                <li>Bisnis & Entrepreneurship</li>
                <li>Pengembangan Diri & Skill</li>
                <li>Kesehatan & Kebugaran</li>
                <li>Teknologi & Digital Skill</li>
                <li>Keuangan & Investasi</li>
            </ul>
        </div>

        <div class="benefit-card">
            <div class="benefit-icon">🚀</div>
            <h3>AKSES INSTANT</h3>
            <p>Setelah pembayaran, Anda langsung mendapatkan:</p>
            <ul class="benefit-list">
                <li>Akses langsung ke semua buku</li>
                <li>Download berbagai format</li>
                <li>Baca di semua perangkat</li>
                <li>Update berkala gratis</li>
                <li>Akses seumur hidup</li>
                <li>Backup di cloud pribadi</li>
            </ul>
        </div>

        <div class="benefit-card">
            <div class="benefit-icon">🎁</div>
            <h3>BONUS EKSKLUSIF</h3>
            <p>Spesial untuk pembeli paket lengkap:</p>
            <ul class="benefit-list">
                <li>Template Bisnis Siap Pakai</li>
                <li>Worksheet & Checklist Premium</li>
                <li>Akses Grup Komunitas</li>
                <li>Video Training Premium</li>
                <li>Konsultasi Gratis 30 Hari</li>
                <li>E-Certificate Penyelesaian</li>
            </ul>
        </div>
    </div>
</div>

<footer>
    <div class="footer-text">
        © <?= date("Y"); ?> TomCamSong Shop. All Rights Reserved.
    </div>
</footer>

</body>
</html>