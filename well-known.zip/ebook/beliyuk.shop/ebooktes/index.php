<?php
// index.php - Landing Page Promo Buku Paketan
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Promo Buku Paketan Terlengkap - Beliyuk Shop</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; background: #f4f4f4; }
        .header { padding: 40px 20px; text-align: center; background: #ff4e00; color: white; }
        .container { max-width: 850px; margin: 30px auto; background: white; padding: 25px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h1 { margin-top: 0; }
        .btn-buy { display: inline-block; padding: 15px 25px; background: #00b341; color: white; text-decoration: none; font-size: 20px; border-radius: 10px; margin-top: 25px; }
        .btn-buy:hover { background: #009c39; }
        .features { margin-top: 20px; font-size: 17px; }
        .features li { margin-bottom: 8px; }
        .price-box { background: #fff7e6; padding: 20px; border-radius: 10px; margin-top: 20px; text-align: center; border: 2px dashed #ff9500; }
        .price-box strong { font-size: 26px; color: #ff4e00; }
        .footer { text-align: center; padding: 20px; font-size: 14px; color: #555; }
    </style>
</head>
<body>

<div class="header">
    <h1>Promo Buku Paketan Terlengkap</h1>
    <p>Dapatkan Paket Buku Terlengkap Dengan Harga Murah Meriah!</p>
</div>

<div class="container">
    <h2>Apa Saja Isi Paket Buku Ini?</h2>
    <p>Paket buku ini berisi kumpulan materi terlengkap, padat, dan mudah dipahami. Sangat cocok untuk kamu yang ingin belajar cepat tanpa ribet.</p>

    <ul class="features">
        <li>✓ Puluhan materi pilihan dalam 1 paket</li>
        <li>✓ Format rapi & mudah dipelajari</li>
        <li>✓ Hemat biaya – lebih murah daripada beli satuan</li>
        <li>✓ Bonus file tambahan</li>
    </ul>

    <div class="price-box">
        <h2>Harga Promo Spesial</h2>
        <p><strong>Rp 20.000</strong></p>
        <p>Promo terbatas! Akses langsung setelah pembayaran.</p>
    </div>

    <center>
        <a class="btn-buy" href="create-payment.php">Beli Sekarang</a>
    </center>
</div>

<div class="footer">
    © <?php echo date("Y"); ?> Beliyuk Shop. All Rights Reserved.
</div>

</body>
</html>
