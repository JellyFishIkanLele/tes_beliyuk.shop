<?php
$va        = "1179009513151027";
$apiKey    = "EA1AC0D0-13BB-4DE3-B42F-A1890C8577E3";
$url       = "https://my.ipaymu.com/api/v2/payment";

// DATA
$data = [
    'product'     => ["Ebook Premium"],
    'qty'         => [1],
    'price'       => [1000],

    'returnUrl'   => "https://beliyuk.shop/ebook/success_payment",
    'successUrl'  => "https://beliyuk.shop/ebook/success_payment",
    'cancelUrl'   => "https://beliyuk.shop/ebook/",
    'notifyUrl'   => "https://beliyuk.shop/ebook/callback-ipaymu.php",

    'buyerName'   => "Customer",
    'buyerPhone'  => "0000000000",
    'buyerEmail'  => "noemail@domain.com",

    'referenceId' => strval(time()),
];

// SIGNATURE
$bodyJson = json_encode($data, JSON_UNESCAPED_SLASHES);
$bodyHashLower = strtolower(hash('sha256', $bodyJson));

$stringToSign = "POST:" . $va . ":" . $bodyHashLower . ":" . $apiKey;
$signature = hash_hmac('sha256', $stringToSign, $apiKey);

$timestamp = date('YmdHis');

// CURL
$ch = curl_init($url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $bodyJson);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, [
    'Content-Type: application/json',
    'va: ' . $va,
    'signature: ' . $signature,
    'timestamp: ' . $timestamp
]);

$response = curl_exec($ch);
curl_close($ch);

$result = json_decode($response, true);

if (isset($result['Data']['Url'])) {
    header("Location: " . $result['Data']['Url']);
    exit;
} else {
    echo "Gagal membuat pembayaran:<br><pre>";
    print_r($result);
    echo "</pre>";
}
?>
