<?php
// ===============================
// KONFIGURASI
// ===============================
$yourApiKey = "EA1AC0D0-13BB-4DE3-B42F-A1890C8577E3";
$yourVA     = "1179009513151027";

// Folder untuk log callback
$logFolder = __DIR__ . "/logs";
if (!is_dir($logFolder)) {
    mkdir($logFolder, 0777, true);
}

// ===============================
// 1. AMBIL INPUT RAW CALLBACK
// ===============================
$raw = file_get_contents("php://input");
$data = json_decode($raw, true);

// Log raw callback
file_put_contents($logFolder . "/callback_raw_" . time() . ".json", $raw);

// Jika tidak ada data → matikan
if (!$data) {
    http_response_code(400);
    echo "NO DATA";
    exit;
}

// ===============================
// 2. VALIDASI SIGNATURE
// ===============================
$receivedSignature = $_SERVER['HTTP_SIGNATURE'] ?? '';

$bodyHash   = strtolower(hash('sha256', $raw));
$stringSign = "POST:" . $yourVA . ":" . $bodyHash . ":" . $yourApiKey;

$expectedSignature = hash_hmac('sha256', $stringSign, $yourApiKey);

if ($receivedSignature !== $expectedSignature) {

    // Log gagal signature
    file_put_contents(
        $logFolder . "/signature_failed_" . time() . ".log",
        "Expected: $expectedSignature\nReceived: $receivedSignature\nRaw: $raw"
    );

    http_response_code(401);
    echo "INVALID SIGNATURE";
    exit;
}

// ===============================
// 3. PROSES DATA CALL BACK
// ===============================
$referenceId   = $data["referenceId"] ?? "-";
$status        = $data["status"] ?? "-"; // 1 = PAID
$amount        = $data["amount"] ?? 0;
$paymentMethod = $data["paymentMethod"] ?? "";
$paymentNo     = $data["paymentNo"] ?? "-";

// ===============================
// 4. SIMPAN LOG SUKSES
// ===============================
$log = "REFERENCE: $referenceId\n"
     . "STATUS: $status\n"
     . "AMOUNT: $amount\n"
     . "METHOD: $paymentMethod\n"
     . "PAYMENT NO: $paymentNo\n"
     . "RAW: $raw\n\n";

file_put_contents($logFolder . "/callback_success_" . time() . ".log", $log);

// ===============================
// 5. JIKA INGIN TINDAKAN TAMBAHAN
// ===============================

// Jika pembayaran sukses (status = 1)
if ($status == 1) {

    // Contoh: kirim email, update DB, beri akses ebook, dll.

    // Simpan status paid
    file_put_contents(
        $logFolder . "/paid_" . $referenceId . ".txt",
        "PAID | " . date("Y-m-d H:i:s")
    );
}

// ===============================
// 6. RESPONSE KE IPAYMU → WAJIB 200
// ===============================
http_response_code(200);
echo "OK";
?>
