<?php
// --- KONFIGURASI (UBAH SESUAI KEBUTUHAN) ---
$nama_toko      = "BeliYuk Shop";
$nama_produk    = "100 Video Sains & Ebook Premium";
$harga_produk   = "Rp 49.000"; // Sesuaikan harga promo
$link_download  = "https://google.com"; // GANTI DENGAN LINK FILE ASLI ANDA
$no_wa          = "628123456789"; // Ganti No WA Admin
$pesan_wa       = "Halo, saya butuh bantuan akses produk Video Sains.";

// Simulasi Data Transaksi (Otomatis Tanggal Hari Ini)
$order_id       = "INV-" . strtoupper(uniqid()); 
$tanggal        = date("d M Y, H:i") . " WIB";
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Transaksi Berhasil - <?php echo $nama_toko; ?></title>
    <style>
        /* Reset CSS */
        * { box-sizing: border-box; margin: 0; padding: 0; font-family: 'Helvetica Neue', Helvetica, Arial, sans-serif; }
        
        body {
            background-color: #eef2f5;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
            padding: 20px;
        }

        .receipt-card {
            background: white;
            width: 100%;
            max-width: 480px;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0,0,0,0.08);
            overflow: hidden;
            position: relative;
        }

        /* Bagian Header Hijau */
        .header {
            background-color: #27ae60;
            padding: 40px 20px 30px;
            text-align: center;
            color: white;
            position: relative;
        }

        /* Icon Centang Animasi */
        .success-icon-bg {
            background: white;
            width: 70px;
            height: 70px;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0 auto 15px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }
        .success-icon {
            color: #27ae60;
            font-size: 36px;
            font-weight: bold;
        }

        .header h1 { font-size: 22px; font-weight: 700; margin-bottom: 5px; }
        .header p { font-size: 14px; opacity: 0.9; }

        /* Bagian Isi Struk */
        .content { padding: 30px 25px; }

        .status-badge {
            background-color: #e8f8f5;
            color: #27ae60;
            border: 1px solid #27ae60;
            padding: 8px 20px;
            border-radius: 50px;
            font-size: 14px;
            font-weight: 800;
            display: inline-block;
            margin-bottom: 25px;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .receipt-details {
            border-top: 2px dashed #e0e0e0;
            border-bottom: 2px dashed #e0e0e0;
            padding: 20px 0;
            margin-bottom: 25px;
        }

        .row {
            display: flex;
            justify-content: space-between;
            margin-bottom: 12px;
            font-size: 14px;
            color: #555;
        }
        .row:last-child { margin-bottom: 0; }
        .row strong { color: #333; font-weight: 600; }
        .total-row {
            display: flex;
            justify-content: space-between;
            margin-top: 15px;
            font-size: 18px;
            font-weight: bold;
            color: #27ae60;
        }

        /* Tombol */
        .btn-group { display: flex; flex-direction: column; gap: 12px; }
        
        .btn {
            display: block;
            width: 100%;
            padding: 15px;
            border-radius: 10px;
            text-decoration: none;
            font-weight: 700;
            text-align: center;
            font-size: 15px;
            transition: 0.2s;
            cursor: pointer;
            border: none;
        }

        .btn-primary {
            background-color: #27ae60; /* Hijau Scalev/Tokopedia style */
            color: white;
            box-shadow: 0 4px 15px rgba(39, 174, 96, 0.3);
        }
        .btn-primary:hover { background-color: #219150; transform: translateY(-2px); }

        .btn-secondary {
            background-color: #f1f2f6;
            color: #7f8c8d;
        }
        .btn-secondary:hover { background-color: #e1e2e6; }

        .note {
            margin-top: 20px;
            font-size: 12px;
            color: #95a5a6;
            text-align: center;
            line-height: 1.5;
        }

        /* Animasi Pop Up */
        @keyframes popup {
            0% { transform: scale(0.8); opacity: 0; }
            100% { transform: scale(1); opacity: 1; }
        }
        .receipt-card { animation: popup 0.5s cubic-bezier(0.175, 0.885, 0.32, 1.275); }
    </style>
</head>
<body>

    <div class="receipt-card">
        <div class="header">
            <div class="success-icon-bg">
                <div class="success-icon">✓</div>
            </div>
            <h1>PEMBAYARAN SUKSES!</h1>
            <p>Terima kasih, pesanan Anda telah kami terima.</p>
        </div>

        <div class="content" style="text-align: center;">
            
            <div class="status-badge">STATUS: LUNAS</div>

            <div class="receipt-details">
                <div class="row">
                    <span>No. Invoice</span>
                    <strong><?php echo $order_id; ?></strong>
                </div>
                <div class="row">
                    <span>Tanggal</span>
                    <strong><?php echo $tanggal; ?></strong>
                </div>
                <div class="row">
                    <span>Item</span>
                    <strong style="max-width: 60%; text-align: right;"><?php echo $nama_produk; ?></strong>
                </div>
                <div class="total-row">
                    <span>Total Bayar</span>
                    <span><?php echo $harga_produk; ?></span>
                </div>
            </div>

            <div class="btn-group">
                <a href="<?php echo $link_download; ?>" class="btn btn-primary">
                    📂 AKSES PRODUK SEKARANG
                </a>
                
                <a href="https://wa.me/<?php echo $no_wa; ?>?text=<?php echo urlencode($pesan_wa); ?>" class="btn btn-secondary">
                    Butuh Bantuan? Hubungi Admin
                </a>
            </div>

            <p class="note">
                Bukti pembayaran ini sah dan diterbitkan secara otomatis oleh sistem <?php echo $nama_toko; ?>.
                Silakan simpan Order ID Anda.
            </p>
        </div>
    </div>

</body>
</html>