<?php
session_start();

// ==========================
// CONFIG
// ==========================
$merchantCode = "DS26703"; 
$apiKey       = "1eb189e081cc2e1ff17b8a6f29a0ec61";

// LINK DOWNLOAD UTAMA
$downloadLink = "https://drive.google.com/file/d/1QoPPDRFdr0qh5wtD_dBkFTdYvB09bFbb/view";

// ==========================
// NAMA PRODUK
// ==========================
$productName = "The Psychology of Money E-BOOKS (indo)";

// ==========================
// GET merchantOrderId
// ==========================
if (!isset($_GET['merchantOrderId'])) {
    if (isset($_SESSION['order_id'])) {
        $merchantOrderId = $_SESSION['order_id'];
    } else {
        die("Invalid Request: merchantOrderId missing.");
    }
} else {
    $merchantOrderId = $_GET['merchantOrderId'];
}

// ==========================
// SIGNATURE CEK STATUS
// ==========================
$signature = md5($merchantCode . $merchantOrderId . $apiKey);

// ==========================
// REQUEST BODY
// ==========================
$data = array(
    "merchantCode"     => $merchantCode,
    "merchantOrderId"  => $merchantOrderId,
    "signature"        => $signature
);

$jsonData = json_encode($data);

// ==========================
// CURL REQUEST KE DUITKU
// ==========================
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://sandbox.duitku.com/webapi/api/merchant/transactionStatus");
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
    "Content-Type: application/json",
    "Content-Length: " . strlen($jsonData)
));

$response = curl_exec($ch);
curl_close($ch);

// ==========================
// PARSE RESPONSE
// ==========================
$result = json_decode($response, true);
$status = $result["statusCode"] ?? "??";

// ==========================
// AMOUNT DINAMIS DARI DUITKU
// ==========================
$amountAPI = isset($result["amount"]) ? (int)$result["amount"] : 0;
$amountFormatted = number_format($amountAPI, 0, ',', '.');

// ==========================
// HITUNG QUANTITY DARI AMOUNT
// ==========================
$pricePerItem = 99999; // Harga per paket
$quantity = 1; // Default

if ($amountAPI > 0 && $pricePerItem > 0) {
    $quantity = floor($amountAPI / $pricePerItem);
    if ($quantity < 1) $quantity = 1;
}

// Cek jika ada quantity di session
if (isset($_SESSION['quantity']) && $_SESSION['quantity'] > 0) {
    $quantity = $_SESSION['quantity'];
}

// ==========================
// KIRIM EMAIL JIKA PEMBAYARAN BERHASIL
// ==========================
if ($status == "00") {
    // Fungsi kirim email dengan quantity dan nama produk
    function sendBackupEmail($toEmail, $orderId, $amount, $quantity, $downloadLink, $productName) {
        $formattedAmount = number_format($amount, 0, ',', '.');
        
        $subject = "📦 " . $productName . " ($quantity paket) - Order #" . $orderId;
        
        $message = '
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="UTF-8">
            <title>Akses ' . $productName . '</title>
            <style>
                body { font-family: Arial, sans-serif; line-height:1.6; margin:0; padding:20px; background:#f5f5f5; }
                .container { max-width:600px; margin:0 auto; background:white; border-radius:10px; padding:25px; box-shadow:0 2px 10px rgba(0,0,0,0.1); }
                .header { text-align:center; padding-bottom:20px; border-bottom:2px solid #facc15; }
                .btn-download { display:inline-block; background:#22c55e; color:white; padding:14px 28px; text-decoration:none; border-radius:8px; font-weight:bold; font-size:16px; margin:15px 0; }
                .details { background:#f8f9fa; padding:15px; border-radius:8px; margin:15px 0; }
                .footer { margin-top:20px; padding-top:15px; border-top:1px solid #ddd; color:#666; font-size:13px; }
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h2 style="color:#22c55e; margin:0 0 10px 0;">✅ ' . $productName . ' SIAP!</h2>
                    <p style="color:#666; margin:0;">Order #' . $orderId . '</p>
                </div>
                
                <div style="margin:20px 0;">
                    <p><strong>Nama Produk:</strong> ' . $productName . '</p>
                    <p><strong>Jumlah Paket:</strong> ' . $quantity . ' paket</p>
                    <p><strong>Total:</strong> Rp ' . $formattedAmount . '</p>
                    <p><strong>Tanggal:</strong> ' . date("d/m/Y H:i:s") . '</p>
                </div>
                
                <div style="text-align:center; margin:25px 0;">
                    <a href="' . $downloadLink . '" class="btn-download" target="_blank">
                        📥 AKSES SEKARANG (' . $quantity . ' Paket)
                    </a>
                    <p style="color:#666; font-size:14px; margin-top:10px;">
                        Terimakasih Telah Berbelanja💕
                    </p>
                </div>
                
                <div class="details">
                    <h3 style="margin-top:0;">📋 Petunjuk:</h3>
                    <ol>
                        <li>Klik tombol "AKSES SEKARANG" di atas</li>
                        <li>Silahkan di Baca Ebook anda</li>
                    </ol>
                </div>
                
                <div class="footer">
                    <p>Terima kasih telah berbelanja di <strong>Beliyuk.Shop</strong></p>
                    <p>Butuh bantuan? Email: support@beliyuk.shop</p>
                    <p>© ' . date('Y') . ' Beliyuk Shop. All rights reserved.</p>
                </div>
            </div>
        </body>
        </html>';
        
        $headers = "MIME-Version: 1.0" . "\r\n";
        $headers .= "Content-type:text/html;charset=UTF-8" . "\r\n";
        $headers .= "From: Beliyuk Shop <noreply@beliyuk.shop>" . "\r\n";
        $headers .= "Reply-To: support@beliyuk.shop" . "\r\n";
        $headers .= "X-Mailer: PHP/" . phpversion();
        
        return mail($toEmail, $subject, $message, $headers);
    }
    
    // Kirim email backup jika ada email di session
    if (isset($_SESSION['customer_email']) && !empty($_SESSION['customer_email'])) {
        sendBackupEmail(
            $_SESSION['customer_email'], 
            $merchantOrderId, 
            $amountAPI, 
            $quantity,
            $downloadLink,
            $productName
        );
        
        // Hapus session setelah pengiriman
        unset($_SESSION['customer_email']);
        unset($_SESSION['quantity']);
        unset($_SESSION['order_id']);
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Status Pembayaran - Beliyuk Shop</title>

<?php include $_SERVER['DOCUMENT_ROOT'] . '/pixel.php'; ?>

<?php if ($status == "00") { ?>
<!-- META PIXEL PURCHASE EVENT -->
<script>
fbq('track', 'Purchase', {
    value: <?= $amountAPI ?>,
    currency: 'IDR',
    content_ids: ["72e1rdnnrd"],
    content_name: "<?= $productName ?>",
    content_type: 'product',
    num_items: <?= $quantity ?>
});
</script>
<?php } ?>

<style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background: linear-gradient(135deg, #0d0d0d 0%, #1a1a1a 100%);
        margin: 0;
        padding: 20px;
        color: #f5f5f5;
        min-height: 100vh;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .container {
        max-width: 500px;
        background: #1a1a1a;
        padding: 40px;
        border-radius: 20px;
        box-shadow: 0 10px 30px rgba(0, 0, 0, 0.5);
        text-align: center;
        position: relative;
        border: 2px solid rgba(250, 204, 21, 0.3);
    }

    .icon {
        font-size: 80px;
        margin-bottom: 20px;
        animation: bounce 1s ease infinite alternate;
    }
    @keyframes bounce {
        from { transform: translateY(0); }
        to { transform: translateY(-10px); }
    }
    
    .success { color: #22c55e; }
    .pending { color: #facc15; }
    .failed  { color: #ef4444; }

    h2 {
        margin: 10px 0;
        font-weight: 800;
        color: #facc15;
        font-size: 28px;
    }

    .details {
        text-align: left;
        margin: 30px 0;
        background: rgba(255, 255, 255, 0.05);
        padding: 20px;
        border-radius: 12px;
        font-size: 15px;
        line-height: 1.7;
        border-left: 4px solid #facc15;
    }

    .details b {
        color: #facc15;
    }

    .btn-access {
        display: inline-block;
        width: 100%;
        padding: 18px;
        background: linear-gradient(135deg, #22c55e, #16a34a);
        color: white;
        text-decoration: none;
        border-radius: 12px;
        font-size: 18px;
        font-weight: 800;
        margin: 20px 0;
        border: none;
        cursor: pointer;
        transition: all 0.3s ease;
        box-shadow: 0 5px 20px rgba(34, 197, 94, 0.3);
        text-align: center;
    }
    
    .btn-access:hover {
        transform: translateY(-3px);
        box-shadow: 0 8px 25px rgba(34, 197, 94, 0.4);
        background: linear-gradient(135deg, #16a34a, #15803d);
    }
    
    .btn-access:active {
        transform: translateY(-1px);
    }

    .btn-back {
        display: inline-block;
        width: 100%;
        padding: 16px;
        background: rgba(250, 204, 21, 0.1);
        color: #facc15;
        text-decoration: none;
        border-radius: 12px;
        font-size: 16px;
        font-weight: 600;
        border: 2px solid #facc15;
        transition: all 0.3s ease;
        text-align: center;
        margin-top: 10px;
    }
    
    .btn-back:hover {
        background: rgba(250, 204, 21, 0.2);
    }

    .quantity-badge {
        display: inline-block;
        background: rgba(250, 204, 21, 0.2);
        color: #facc15;
        padding: 8px 16px;
        border-radius: 20px;
        font-weight: 700;
        margin: 15px 0;
        border: 2px solid rgba(250, 204, 21, 0.3);
    }
    
    .product-name {
        display: inline-block;
        background: rgba(59, 130, 246, 0.2);
        color: #93c5fd;
        padding: 8px 16px;
        border-radius: 10px;
        font-weight: 600;
        margin: 10px 0 15px 0;
        border: 2px solid rgba(59, 130, 246, 0.3);
    }
    
    .email-notice {
        background: rgba(34, 197, 94, 0.15);
        padding: 20px;
        border-radius: 12px;
        margin: 25px 0;
        border-left: 4px solid #22c55e;
        border-right: 1px solid rgba(34, 197, 94, 0.3);
    }
    
    .email-notice strong {
        color: #86efac;
    }
    
    p {
        color: #ddd;
        margin: 10px 0;
    }
    
    .download-instruction {
        background: rgba(59, 130, 246, 0.1);
        padding: 15px;
        border-radius: 10px;
        margin: 20px 0;
        font-size: 14px;
        color: #93c5fd;
        border-left: 4px solid #3b82f6;
    }
    
    .button-section {
        margin-top: 30px;
        padding-top: 20px;
        border-top: 1px solid rgba(255, 255, 255, 0.1);
    }
</style>

</head>
<body>

<div class="container">

<?php if ($status == "00") { ?>

    <div class="icon success">✅</div>
    <h2>Pembayaran Berhasil!</h2>
    
    <div class="product-name">
        📚 <?= htmlspecialchars($productName) ?>
    </div>
    
    <div class="quantity-badge">
        📦 <?= $quantity ?> Paket E-Book
    </div>
    
    <p>Terima kasih! Pembayaran <b style="color:#facc15;">Rp <?= $amountFormatted ?></b> telah diterima.</p>

<?php } elseif ($status == "01") { ?>

    <div class="icon pending">⏳</div>
    <h2>Pembayaran Pending</h2>
    <p>Pembayaran Anda belum selesai. Silakan lanjutkan pembayaran.</p>

<?php } else { ?>

    <script>
        setTimeout(function() { history.back(); }, 2000);
    </script>

    <div class="icon failed">❌</div>
    <h2>Pembayaran Gagal</h2>
    <p>Silakan coba lagi atau hubungi support.</p>

<?php } ?>

    <div class="details">
        <b>📋 Detail Transaksi:</b><br>
        Order ID: <?= htmlspecialchars($result["merchantOrderId"] ?? "-") ?><br>
        Nama Produk: <?= htmlspecialchars($productName) ?><br>
        Jumlah Paket: <?= $quantity ?> paket<br>
        Reference: <?= htmlspecialchars($result["reference"] ?? "-") ?><br>
        Amount: Rp <?= $amountFormatted ?><br>
        Status Code: <?= htmlspecialchars($status) ?><br>
        Message: <?= htmlspecialchars($result["statusMessage"] ?? "Completed") ?><br>
    </div>
    
    <!-- SECTION TOMBOL DI BAWAH DETAIL TRANSAKSI -->
    <div class="button-section">
        <?php if ($status == "00") { ?>
            <!-- HANYA UNTUK PEMBAYARAN SUKSES -->
            <a class="btn-back" href="https://beliyuk.shop/">
                🏠 Kembali ke Beranda
            </a>
        <?php } elseif ($status == "01") { ?>
            <!-- HANYA UNTUK PEMBAYARAN PENDING -->
            <a class="btn-back" href="javascript:history.back();">
                ⬅ Kembali ke Pembayaran
            </a>
        <?php } else { ?>
            <!-- HANYA UNTUK PEMBAYARAN GAGAL -->
            <a class="btn-back" href="javascript:history.back();">
                🔄 Coba Lagi
            </a>
        <?php } ?>
    </div>

</div>

<script>
// Track ketika tombol download diklik
function trackDownloadClick() {
    console.log('Tombol download diklik');
    
    // Facebook Pixel - Track Download
    if (typeof fbq !== 'undefined') {
        fbq('track', 'Lead', {
            value: <?= $amountAPI ?>,
            currency: 'IDR',
            content_name: '<?= $productName ?> Download'
        });
    }
    
    // Google Analytics (jika ada)
    if (typeof gtag !== 'undefined') {
        gtag('event', 'download', {
            'event_category': 'product',
            'event_label': '<?= strtolower(str_replace(" ", "-", $productName)) ?>',
            'value': <?= $quantity ?>
        });
    }
    
    // Simpan ke localStorage bahwa sudah diklik
    localStorage.setItem('beliyuk_download_clicked', 'true');
    localStorage.setItem('beliyuk_order_id', '<?= $merchantOrderId ?>');
}

// Auto-redirect jika 10 detik tidak diklik (fallback)
<?php if ($status == "00") { ?>
setTimeout(function() {
    if (!localStorage.getItem('beliyuk_download_clicked')) {
        console.log('Auto-redirect ke download page');
        window.open('<?= $downloadLink ?>', '_blank');
    }
}, 10000);
<?php } ?>
</script>

</body>
</html>